#include "esp32_s3_composite_video.h"

uint8_t* esp32_s3_composite_video::_framebuffer = nullptr;
volatile int esp32_s3_composite_video::_current_line = 0;
esp_lcd_panel_handle_t esp32_s3_composite_video::_panel_handle = nullptr;

DRAM_ATTR static int _shared_pins[8] = {0};

esp32_s3_composite_video::esp32_s3_composite_video() {}

esp32_s3_composite_video::~esp32_s3_composite_video() {
    if (_panel_handle) {
        esp_lcd_panel_del(_panel_handle);
    }
}

bool esp32_s3_composite_video::begin(const int user_pins[]) {
    for (int i = 0; i < 8; i++) {
        _shared_pins[i] = user_pins[i];
    }

    esp_lcd_rgb_panel_config_t panel_config = {};
    panel_config.clk_src = LCD_CLK_SRC_DEFAULT;
    panel_config.timings.pclk_hz = 13500000;
    panel_config.timings.h_res = _hw_width;
    panel_config.timings.v_res = _total_lines;
    panel_config.timings.hsync_pulse_width = 1;
    panel_config.timings.hsync_back_porch = 1;
    panel_config.timings.hsync_front_porch = 1;
    panel_config.timings.vsync_pulse_width = 1;
    panel_config.timings.vsync_back_porch = 1;
    panel_config.timings.vsync_front_porch = 1;
    panel_config.data_width = 8; 
    panel_config.bits_per_pixel = 8;
    panel_config.num_fbs = 1;
    panel_config.bounce_buffer_size_px = 0;
    panel_config.sram_trans_align = 32;
    panel_config.psram_trans_align = 64;
    
    for (int i = 0; i < 16; i++) {
        panel_config.data_gpio_nums[i] = -1;
    }
    for (int i = 0; i < 8; i++) {
        panel_config.data_gpio_nums[i] = _shared_pins[i];
    }

    panel_config.disp_gpio_num = -1;
    panel_config.pclk_gpio_num = -1;

    if (esp_lcd_new_rgb_panel(&panel_config, &_panel_handle) != ESP_OK) return false;
    if (esp_lcd_panel_reset(_panel_handle) != ESP_OK) return false;
    if (esp_lcd_panel_init(_panel_handle) != ESP_OK) return false;

    void* fb_ptr = nullptr;
    esp_lcd_rgb_panel_get_frame_buffer(_panel_handle, 1, &fb_ptr);
    _framebuffer = (uint8_t*)fb_ptr;

    if (!_framebuffer) return false;

    fill(_lvl_black);
    return true;
}

bool esp32_s3_composite_video::begin(int p0, int p1, int p2, int p3, int p4, int p5, int p6, int p7) {
    int temp_pins[8] = {p0, p1, p2, p3, p4, p5, p6, p7};
    return begin(temp_pins);
}

void IRAM_ATTR esp32_s3_composite_video::_write_DAC(uint8_t value) {}
void IRAM_ATTR esp32_s3_composite_video::_onRowTimer(void* arg) {}

void esp32_s3_composite_video::fill(uint8_t color) {
    if (!_framebuffer) return;
    if (color < _lvl_black) color = _lvl_black;

    for (int y = 0; y < _total_lines; y++) {
        uint8_t* row = &_framebuffer[y * _hw_width];

        if (y < 3) {
            memset(row, _lvl_sync, _hw_width);
        } else {
            memset(row, _lvl_sync, 64);
            memset(row + 64, _lvl_black, 64);
            memset(row + 128, color, _hw_width - 128);
        }
    }
}

void esp32_s3_composite_video::_drawRawPixel(int x, int y, uint8_t color) {
    if (!_framebuffer) return;
    if (color < _lvl_black) color = _lvl_black;
    
    if (x >= 0 && x < _width && y >= 0 && y < _height) {
        int real_y = y + 45; 
        int real_x = 140 + (x * 2);

        _framebuffer[real_y * _hw_width + real_x] = color;
        _framebuffer[real_y * _hw_width + real_x + 1] = color;
    }
}

void esp32_s3_composite_video::drawLine(int x0, int y0, int x1, int y1, int thickness, uint8_t brightness) {
    if (thickness < 1) thickness = 1;

    int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
    int dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
    int err = dx + dy, e2;

    while (true) {
        for (int t_x = -thickness / 2; t_x <= thickness / 2; t_x++) {
            for (int t_y = -thickness / 2; t_y <= thickness / 2; t_y++) {
                _drawRawPixel(x0 + t_x, y0 + t_y, brightness);
            }
        }

        if (x0 == x1 && y0 == y1) break;
        e2 = 2 * err;
        if (e2 >= dy) { err += dy; x0 += sx; }
        if (e2 <= dx) { err += dx; y0 += sy; }
    }
}
