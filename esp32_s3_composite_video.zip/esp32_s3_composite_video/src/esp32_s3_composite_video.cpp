#include "esp32_s3_composite_video.h"

uint8_t* esp32_s3_composite_video::_framebuffer = nullptr;
volatile int esp32_s3_composite_video::_current_line = 0;

DRAM_ATTR static int _shared_pins[8] = {0};

esp32_s3_composite_video::esp32_s3_composite_video() {
    _framebuffer = (uint8_t*)malloc(_width * _height);
}

esp32_s3_composite_video::~esp32_s3_composite_video() {
    if (_framebuffer) free(_framebuffer);
}

bool esp32_s3_composite_video::begin(const int user_pins[]) {
    if (!_framebuffer) return false;

    for (int i = 0; i < 8; i++) {
        _shared_pins[i] = user_pins[i];
        gpio_reset_pin((gpio_num_t)_shared_pins[i]);
        gpio_set_direction((gpio_num_t)_shared_pins[i], GPIO_MODE_OUTPUT);
        gpio_set_level((gpio_num_t)_shared_pins[i], 0);
    }

    clear(_lvl_black);

    const esp_timer_create_args_t timer_args = {
        .callback = &esp32_s3_composite_video::_onRowTimer,
        .name = "s3_pal_fixed_timer"
    };
    esp_timer_handle_t pal_timer;
    esp_timer_create(&timer_args, &pal_timer);
    esp_timer_start_periodic(pal_timer, 64);

    return true;
}

bool esp32_s3_composite_video::begin(int p0, int p1, int p2, int p3, int p4, int p5, int p6, int p7) {
    int temp_pins[8] = {p0, p1, p2, p3, p4, p5, p6, p7};
    return begin(temp_pins);
}

void IRAM_ATTR esp32_s3_composite_video::_write_DAC(uint8_t value) {
    gpio_set_level((gpio_num_t)_shared_pins[0], (value >> 0) & 1);
    gpio_set_level((gpio_num_t)_shared_pins[1], (value >> 1) & 1);
    gpio_set_level((gpio_num_t)_shared_pins[2], (value >> 2) & 1);
    gpio_set_level((gpio_num_t)_shared_pins[3], (value >> 3) & 1);
    gpio_set_level((gpio_num_t)_shared_pins[4], (value >> 4) & 1);
    gpio_set_level((gpio_num_t)_shared_pins[5], (value >> 5) & 1);
    gpio_set_level((gpio_num_t)_shared_pins[6], (value >> 6) & 1);
    gpio_set_level((gpio_num_t)_shared_pins[7], (value >> 7) & 1);
}

void IRAM_ATTR esp32_s3_composite_video::_onRowTimer(void* arg) {
    _current_line++;
    if (_current_line > _total_lines) _current_line = 1;

    if (_current_line <= 3) {
        _write_DAC(_lvl_sync);
        return;
    }

    _write_DAC(_lvl_sync); 
    ets_delay_us(_time_sync);

    _write_DAC(_lvl_black); 
    ets_delay_us(_time_blank);

    int video_y = _current_line - 40;
    if (video_y >= 0 && video_y < _height) {
        uint8_t* line_ptr = &_framebuffer[video_y * _width];
        for (int x = 0; x < _width; x++) {
            _write_DAC(line_ptr[x]);
        }
    } else {
        _write_DAC(_lvl_black);
        ets_delay_us(53);
    }
}

void esp32_s3_composite_video::clear(uint8_t color) {
    if (color < 60) color = 60; 
    if (_framebuffer) memset(_framebuffer, color, _width * _height);
}

void esp32_s3_composite_video::_drawRawPixel(int x, int y, uint8_t color) {
    if (color < 60) color = 60; 
    if (x >= 0 && x < _width && y >= 0 && y < _height) {
        _framebuffer[y * _width + x] = color;
    }
}

void esp32_s3_composite_video::drawLine(int x0, int y0, int x1, int y1, int thickness, uint8_t brightness) {
    if (thickness < 1) thickness = 1;

    int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
    int dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
    int err = dx + dy, e2;

    while (true) {
        for (int t_x = -thickness / 2; t_x <= thickness / 2; t_x++) {
            for (int t_y = -thickness / 2; t_y <= thickness / 2; t_y++) {
                _drawRawPixel(x0 + t_x, y0 + t_y, brightness);
            }
        }

        if (x0 == x1 && y0 == y1) break;
        e2 = 2 * err;
        if (e2 >= dy) { err += dy; x0 += sx; }
        if (e2 <= dx) { err += dx; y0 += sy; }
    }
}
