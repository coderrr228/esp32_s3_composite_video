#pragma once
#include <Arduino.h>
#include "driver/gpio.h"
#include "esp_timer.h"

class esp32_s3_composite_video {
private:
    static const int _width = 320;
    static const int _height = 220;
    static const int _total_lines = 312; 
    
    static const uint8_t _lvl_sync = 0;   
    static const uint8_t _lvl_black = 60; 
    
    static const uint64_t _time_sync = 5;  
    static const uint64_t _time_blank = 6; 

    static uint8_t* _framebuffer;
    static volatile int _current_line;

    static void IRAM_ATTR _onRowTimer(void* arg);
    static void IRAM_ATTR _write_DAC(uint8_t value);
    
    void _drawRawPixel(int x, int y, uint8_t color);

public:
    esp32_s3_composite_video();
    ~esp32_s3_composite_video();

    bool begin(const int user_pins[]);

    bool begin(int p0, int p1, int p2, int p3, int p4, int p5, int p6, int p7);

    void clear(uint8_t color = 60);
    void drawLine(int x0, int y0, int x1, int y1, int thickness, uint8_t brightness);
    
    int width() const { return _width; }
    int height() const { return _height; }
};
